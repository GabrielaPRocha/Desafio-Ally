import  React from 'react'

import CardCurso from "../../cardCurso/CardCurso";

export default function Pgprinc(){
    return(
        <div className="content">
            <CardCurso/>
            <CardCurso/>
            <CardCurso/>
        </div>
    );
}