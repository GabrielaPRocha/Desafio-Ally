import React from 'react'
import "./style.css"
export default function Sobre(){
    return(
        <>
        <div className="about">
        <h1 className="tittle">Sobre a Pagina</h1>
        <p className="description">aljsdhfalkdjhfalkjfhafdjkajkjjkfajh</p>
        </div>
        </>
    );
}